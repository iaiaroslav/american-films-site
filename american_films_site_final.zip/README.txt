American Films - ready-to-upload

Files:
- index.html
- styles.css
- script.js
- images/logo.png

How to use:
1. Download the ZIP and extract files.
2. Upload all files to your GitHub repository root (Add file → Upload files).
3. Commit changes.
4. Open: https://iaiaroslav.github.io/american-films-site/

Notes:
- Poster images are loaded from TMDB (external URLs). If some images fail to load, refresh or wait a minute.
- Logo is a simple green 'A' in images/logo.png. Replace with your own if desired.
- Modal opens inside the page (no server required).
