// script.js - render cards, open modal with film details
const films = [
  // Popular (8)
  {id:'inception',title:'Inception',year:2010,rating:8.8,genres:'Sci-Fi, Thriller',overview:'A thief who enters people\'s dreams to steal secrets is asked to plant an idea instead.',poster:'https://image.tmdb.org/t/p/w780/qmDpIHrmpJINaRKAfWQfftjCdyi.jpg',section:'popular'},
  {id:'interstellar',title:'Interstellar',year:2014,rating:8.6,genres:'Adventure, Drama, Sci-Fi',overview:'A team travels through a wormhole seeking a new home for humanity.',poster:'https://image.tmdb.org/t/p/w780/nBNZadXqJSdt05SHLqgT0HuC5Gm.jpg',section:'popular'},
  {id:'avatar',title:'Avatar',year:2009,rating:7.8,genres:'Action, Adventure, Fantasy',overview:'A paraplegic marine on an alien planet torn between duty and his new life.',poster:'https://image.tmdb.org/t/p/w780/jRXYjXNq0Cs2TcJjLkki24MLp7u.jpg',section:'popular'},
  {id:'darkknight',title:'The Dark Knight',year:2008,rating:9.0,genres:'Action, Crime, Drama',overview:'Batman faces the Joker, a criminal mastermind who wants to plunge Gotham into chaos.',poster:'https://image.tmdb.org/t/p/w780/qJ2tW6WMUDux911r6m7haRef0WH.jpg',section:'popular'},
  {id:'titanic',title:'Titanic',year:1997,rating:7.8,genres:'Drama, Romance',overview:'A tragic love story aboard the ill-fated RMS Titanic.',poster:'https://image.tmdb.org/t/p/w780/9xjZS2rlVxm8SFx8kPC3aIGCOYQ.jpg',section:'popular'},
  {id:'shawshank',title:'The Shawshank Redemption',year:1994,rating:9.3,genres:'Drama',overview:'Two imprisoned men form a friendship and find redemption over the years.',poster:'https://image.tmdb.org/t/p/w780/5KCVkau1HEl7ZzfPsKAPM0sMiKc.jpg',section:'popular'},
  {id:'forrest',title:'Forrest Gump',year:1994,rating:8.8,genres:'Drama, Romance',overview:'A simple man unwittingly influences major historical events while searching for love.',poster:'https://image.tmdb.org/t/p/w780/saHP97rTPS5eLmrLQEcANmKrsFl.jpg',section:'popular'},
  {id:'jurassic',title:'Jurassic Park',year:1993,rating:8.1,genres:'Adventure, Sci-Fi',overview:'Cloned dinosaurs escape and wreak havoc in a theme park.',poster:'https://image.tmdb.org/t/p/w780/c414cDeQ9b6p2z8S7A6mK3XwQXc.jpg',section:'popular'},

  // Classics (6)
  {id:'godfather',title:'The Godfather',year:1972,rating:9.2,genres:'Crime, Drama',overview:'The aging head of a crime family transfers control to his son.',poster:'https://image.tmdb.org/t/p/w780/3bhkrj58Vtu7enYsRolD1fZdja1.jpg',section:'classics'},
  {id:'gladiator',title:'Gladiator',year:2000,rating:8.5,genres:'Action, Drama',overview:'A betrayed Roman general seeks vengeance against the corrupt emperor.',poster:'https://image.tmdb.org/t/p/w780/2GIa1pRnu7t4iRk0gq7l3d0Kp1f.jpg',section:'classics'},
  {id:'pulp',title:'Pulp Fiction',year:1994,rating:8.9,genres:'Crime, Drama',overview:'Interwoven stories of crime and redemption in Los Angeles.',poster:'https://image.tmdb.org/t/p/w780/dM2w364MScsjFf8pfMbaWUcWrR.jpg',section:'classics'},
  {id:'fightclub',title:'Fight Club',year:1999,rating:8.8,genres:'Drama',overview:'An insomniac office worker forms an underground fight club with a soap maker.',poster:'https://image.tmdb.org/t/p/w780/bptfVGEQuv6vDTIMVCHjJ9Dz8PX.jpg',section:'classics'},
  {id:'lionking',title:'The Lion King',year:1994,rating:8.5,genres:'Animation, Adventure',overview:'A young lion prince learns responsibility and courage.',poster:'https://image.tmdb.org/t/p/w780/2CAL2433ZeIihfX1Hb2139CX0pW.jpg',section:'classics'},
  {id:'back',title:'Back to the Future',year:1985,rating:8.5,genres:'Adventure, Comedy, Sci-Fi',overview:'A teen accidentally travels back in time in a DeLorean car.',poster:'https://image.tmdb.org/t/p/w780/pTpxQB1N0waaSc3OSn0e9oc8kx9.jpg',section:'classics'},

  // New releases (6)
  {id:'oppenheimer',title:'Oppenheimer',year:2023,rating:8.5,genres:'Biography, Drama, History',overview:'The story of J. Robert Oppenheimer and the development of the atomic bomb.',poster:'https://image.tmdb.org/t/p/w780/8i8A0aZk2h1Jk3C2XkKq0mPo2Yb.jpg',section:'new'},
  {id:'spiderverse',title:'Spider-Man: Across the Spider-Verse',year:2023,rating:8.4,genres:'Animation, Action, Adventure',overview:'Miles Morales embarks on a huge multiverse adventure.',poster:'https://image.tmdb.org/t/p/w780/8Vt6mWEReuy4Of61Lnj5Xj704m8.jpg',section:'new'},
  {id:'dune',title:'Dune',year:2021,rating:8.0,genres:'Adventure, Sci-Fi',overview:'A noble family becomes embroiled in a battle for control of a desert planet.',poster:'https://image.tmdb.org/t/p/w780/d5NXSklXo0qyIYkgV94XAgMIckC.jpg',section:'new'}
];

const rows = {
  popular: document.getElementById('popular-row'),
  classics: document.getElementById('classics-row'),
  new: document.getElementById('new-row')
};

function createCard(f){
  const card = document.createElement('div'); card.className = 'card'; card.tabIndex=0;
  const img = document.createElement('img'); img.src = f.poster; img.alt = f.title + ' poster'; img.loading='lazy';
  const title = document.createElement('div'); title.className='title'; title.textContent = f.title;
  card.appendChild(img); card.appendChild(title);
  card.addEventListener('click', ()=> openModal(f));
  card.addEventListener('keydown', (e)=> { if(e.key==='Enter') openModal(f); });
  return card;
}

// render
films.forEach(f => {
  const target = rows[f.section] || rows.popular;
  target.appendChild(createCard(f));
});

// modal
const modal = document.getElementById('modal');
const closeBtn = document.getElementById('modal-close');
const modalPoster = document.getElementById('modal-poster');
const modalTitle = document.getElementById('modal-title');
const modalYear = document.getElementById('modal-year');
const modalRating = document.getElementById('modal-rating');
const modalGenres = document.getElementById('modal-genres');
const modalOverview = document.getElementById('modal-overview');

function openModal(f){
  modalPoster.src = f.poster.replace('/w780/','/w780/');
  modalPoster.alt = f.title + ' poster';
  modalTitle.textContent = f.title;
  modalYear.textContent = f.year;
  modalRating.textContent = f.rating;
  modalGenres.textContent = f.genres;
  modalOverview.textContent = f.overview;
  modal.classList.add('open');
  modal.setAttribute('aria-hidden','false');
  document.body.style.overflow='hidden';
}

function closeModal(){
  modal.classList.remove('open');
  modal.setAttribute('aria-hidden','true');
  document.body.style.overflow='';
  modalPoster.src = '';
}

closeBtn.addEventListener('click', closeModal);
modal.addEventListener('click', (e)=> { if(e.target===modal) closeModal(); });
document.addEventListener('keydown', (e)=> { if(e.key==='Escape' && modal.classList.contains('open')) closeModal(); });
