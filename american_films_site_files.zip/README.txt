README - American Films (ready-to-upload)
Files included:
- index.html  (homepage)
- movies.html (Netflix-style movies page)
- styles.css  (site styles)

How to use:
1) Download the ZIP and extract files.
2) Go to your GitHub repository 'iaiaroslav/american-films-site'.
3) Upload the three files to the repository root (Add file → Upload files).
4) Commit changes.
5) Open: https://iaiaroslav.github.io/american-films-site/movies.html

Notes:
- Poster images are loaded from TMDB (external URLs). If some images don't appear, wait a minute and reload (Ctrl+F5).
- If you want all poster images inside the repo (no external URLs), you'll need to download images and place them into an images/ folder and update the <img src> paths.
